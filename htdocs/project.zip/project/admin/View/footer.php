<footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <h6>THÔNG TIN</h6>
                    <p class="text-justify">
                        Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                        Omnis, sed iusto vero veritatis deleniti dolorum quia unde laudantium accusantium officia nobis, 
                        asperiores nemo nihil quasi ex! Quae eum at quos.
                    </p>
                </div>

                <div class="col-xs-6 col-md-3">
                    <h6>SẢN PHẨM</h6>
                    <ul class="footer-links">
                        <li><a href="http://scanfcode.com/category/c-language/" style="color:coral;">Sữa rửa mặt</a></li>
                        <li><a href="http://scanfcode.com/category/front-end-development/" style="color:coral;">Dầu gội đầu</a></li>
                        <li><a href="http://scanfcode.com/category/front-end-development/" style="color:coral;">Sữa tắm</a></li>
                        <li><a href="http://scanfcode.com/category/front-end-development/" style="color:coral;">Khác</a></li>
                      

                    </ul>
                </div>

                <div class="col-xs-6 col-md-3">
                    <h6>THÔNG TIN NHANH</h6>
                    <ul class="footer-links">
                        <li><a href="http://scanfcode.com/about/" style="color:black;">Gọi mua hàng: 1800.1060</a></li>
                        <li><a href="http://scanfcode.com/contact/" style="color:black;">Gọi khiếu nại: 1800.1062</a></li>
                        <li><a href="http://scanfcode.com/contribute-at-scanfcode/" style="color:black;">Gọi bảo hành: 1800.1064</a></li>
                        <li><a href="http://scanfcode.com/privacy-policy/"style="color:black;">Kỹ thuật: 1800.1763</a></li>

                    </ul>
                </div>
            </div>
            <hr>
        </div>
        <div class="container">
                <div class="text-center">
                    <p class="copyright-text">Copyright &copy; 2017 All Rights Reserved by
                        <a href="#">ThanhHangg</a>.
                    </p>
                </div>

        </div>
    </footer>