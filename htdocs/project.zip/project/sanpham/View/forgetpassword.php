<section class="login-block ">
  <div class="text-center" style="margin-left: 400px;">
    <h3 class="text-center text-uppercase" style="color:red"><b>Login Now</b></h3>
    <form action="index.php?action=forgetpass&act=forget_action" class="login-form" method="post">
      <div class="form-group">
        <label for="exampleInputEmail1" class="text-uppercase">Enter Email Address To Send Password Link</label>
        <input type="text" class="form-control" name="email" placeholder="">
      </div>
      <div class="form-check ">
        <input type="submit" name="submit_email" class="bg-warning">
      </div>

    </form>
  </div>
</section>